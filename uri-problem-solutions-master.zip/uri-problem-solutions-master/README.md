uri-problem-solutions
=====================

Set of resolutions for the website: https://www.urionlinejudge.com.br/