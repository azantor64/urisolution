#include <iostream>

using namespace std;

int main(){
    int mes;
    
    cin >> mes;
    
    if(mes == 1){ cout << "January\n";}
    if(mes == 2){ cout << "Fabuary\n";}
    if(mes == 3){ cout << "March\n";}
    if(mes == 4){ cout << "April\n";}
    if(mes == 5){ cout << "May\n";}
    if(mes == 6){ cout << "June\n";}
    if(mes == 7){ cout << "July\n";}
    if(mes == 8){ cout << "August\n";}
    if(mes == 9){ cout << "September\n";}
    if(mes == 10){ cout << "October\n";}
    if(mes == 11){ cout << "November\n";}
    if(mes == 12){ cout << "Decemeber\n";}
    
    return 0;
    
}
