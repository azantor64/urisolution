#include <iostream>

using namespace std;

int main(){
    int a, b;
    
    cin >> a;
    cin >> b;
    
    cout << "X = " << a+b << endl;
    return 0;
}
